export const TOGGLE_BANKING_ALERTS = 'TOGGLE_BANKING_ALERTS'

export const Get_Account_Alerts ='Get_Account_Alerts'
export const Get_Bank_Alerts ='Get_Bank_Alerts'
export const RECEIVE_POSTS='RECEIVE_POSTS'