import * as types from '../actionTypes'
import axios from 'axios'

export const toggleBankingAlerts = (item) => dispatch => {
    dispatch({
        type:types.TOGGLE_BANKING_ALERTS,
        payload: item
    })
}

export function bankingAlerts(bankAlertsData){

    return (dispatch,getState) =>
    {
        return dispatch(fetchPosts(bankAlertsData))
    }

}

function fetchPosts(bankAlertsData){

    return dispatch =>{
        return axios.get('https://localhost:44355/api/BankingAlertGroups')
        .then( function(response){
         console.log(response.data);
            return (response.body.name)
        })
        .then(json=> dispatch(receivePosts(bankAlertsData,json)))
    }

}

function receivePosts(bankAlertsData,json){

    return{
type:types.Get_Bank_Alerts,
bankAlertsData,
posts:json,
receivedAt:Date.now()

    }
}