import * as types from '../actionTypes'
import axios from 'axios'
export function accountAlerts(accountAlertsData){

    return (dispatch,getState) =>
    {
        return dispatch(fetchPosts(accountAlertsData))
    }

}

function fetchPosts(accountAlertsData){

    return dispatch =>{

       return  axios.get('https://localhost:44355/api/CustomerProfiles', {
            headers: {
                'X-External-Id ': '435843731R0094875001',
                'X-Audit-Id':'dd'
            }
        }).then(response=> {
            console.log(response.data);
            return response.data;
        });
     /*   return axios.get('https://localhost:44357/api/notification/accountAlerts')
        .then( function(response){
console.log(response.data);
            return response.data;
        })
        .then(json=> dispatch(receivePosts(accountAlertsData,json)))*/
    }

}

function receivePosts(accountAlertsData,json){

    return{
type:types.Get_Account_Alerts,
accountAlertsData,
posts:json,
receivedAt:Date.now()

    }
}