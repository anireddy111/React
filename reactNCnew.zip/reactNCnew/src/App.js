import React from 'react';
import { Provider } from 'react-redux'
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import landingPage from './containers/landingPage/landingPage';
import securityComponent from './containers/bankingAlerts/bankingAlertsPage';
import lockItComponent from './components/BankingAlerts/Lockit/regionsLockIt';
import accountAlertsComponent from './AccountAlerts/accountAlert';
import addOrEditMethodComponent from './AlertsPreferences/DeliveryMethods/addOrEditMethodCommponent';
import { Route, BrowserRouter, Switch } from 'react-router-dom';
import configureStore from './store';

import landingPageContainer from './containers/landingPageContainer';

const initialState ={
  count:10
}

class App extends React.Component {
  render() {
    return (
      <Provider store={configureStore(initialState)}>
        <div>
          <BrowserRouter>
            {/* <HeaderComponent displaytext="Security Alerts" descriptiontext1="These notifications may include updates to your online banking settings, claims status and other important issues." descriptiontext2="You must select at least one delivery method."/>
      <EmailComponent/>
      <PushNotificationComponent></PushNotificationComponent>
      <TextMessageComponent></TextMessageComponent> */}
            <div id="dvRoutes">
              <Switch>
                <Route exact path="/LandingPage" component={landingPageContainer}></Route>
                <Route exact path="/" component={landingPageContainer}></Route>
                <Route exact path="/securityComponent" component={securityComponent}></Route>
                <Route exact path="/lockItComponent" component={lockItComponent}></Route>
                <Route exact path="/accountAlertsComponent" component={accountAlertsComponent}></Route>
                {/* <Route exact path="/addOrEditMethodComponent" component={addOrEditMethodComponent}></Route> */}
              </Switch>
            </div>
          </BrowserRouter>
        </div>
      </Provider>
    );
  }
}

export default App;
