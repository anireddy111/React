import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import LandingPageComponent from './landingPage/landingPage';
import { bankingAlerts, accountAlerts } from '../actions/actions';

const mapStateToProps = (state) => {
    console.log('statebankAlert', state);
    return {
        landingPage: {
           accountAlert: state.accountAlertsReducer.items,
           bankingAlert: state.bankingAlertsReducer.items

        }

    }

}

const mapDispatchToProps = (dispatch) => {

    return bindActionCreators({ bankingAlerts, accountAlerts }, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(LandingPageComponent);