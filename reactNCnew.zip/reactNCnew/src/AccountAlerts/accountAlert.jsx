import React, { Component } from 'react';
//import { Container } from 'react-bootstrap';
import {Row,Col }from 'react-bootstrap';
 import './accountAlerts.css';
 //import Checkbox from '../shared/checkbox';
 import AccountAlertsSection from '../Shared/accountAlertsSection';
 import RenderCheckboxForAccountAlerts from '../Shared/renderCheckboxForAccountAlerts';
 import HeaderComponent from '../Shared/HeaderComponent';
//const imagePath = process.env.PUBLIC_URL + '/Images/';

class accountAlerts extends Component { 

    constructor(props)
    {
    super(props);
    this.state = {
        email: true,      
      }
    }
      toggleImage(toggler) {
          let togglerstatus = this.state[toggler];
        this.setState({
    [toggler]:!togglerstatus       
        });
      }

render() {
    return ( 
       <div>
           <div className="container-box">
           <Row>
                <HeaderComponent displaytext ="Account Alerts for *1234" descriptiontext1 ="Configure account activity alerts and select how you'd like to recive them" descriptiontext2 ="" >      
                </HeaderComponent>
           </Row>
           <hr></hr>
               <Row>
                    <Col xs="8" sm="8" md="8" lg="8">
                            <div className="headers">
                                <h5>Balance Theshold</h5>                              
                            </div> 
                        </Col>
                        <Col xs="4" sm="4" md="4" lg="4">                          
                        <img className="colrightalign" src={'/Images/' + (this.state['email'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('email')} alt="enable"/> 
                    </Col>
                </Row>
                <div style={{ display: (this.state['email'] ? 'block' : 'none') }}>
                <Row>               
                   <Col xs="12" sm="12" md="12" lg="12">
                        <div>                            
                            <p>Send alert when my balance drops below:</p>
                            <input type="text" className="formatTextBox" />               
                        </div> 
                    </Col>                   
                </Row>
                <AccountAlertsSection />  
                </div>             
                <hr></hr>
                {/* <Row>
                    <Col xs="8" sm="8" md="8" lg="8">
                            <div className="headers">
                                <h5>Deposit Confirmation</h5>                              
                            </div> 
                        </Col>
                        <Col xs="4" sm="4" md="4" lg="4">                                         
                        <img className="colrightalign" src={'/images/' + (this.state['email2'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('email2')} alt="enable"/> 
                    </Col>
                    <div className="col-12" style={{ display: (this.state['email2'] ? 'block' : 'none') }}> 
                                   
                    <AccountAlertsSection /> 
                                        
                    </div>
                </Row>
                <hr></hr> */}
                <RenderCheckboxForAccountAlerts header ="Deposit Confirmation"></RenderCheckboxForAccountAlerts>
                <RenderCheckboxForAccountAlerts header ="Overdraft Posted"></RenderCheckboxForAccountAlerts>
                <RenderCheckboxForAccountAlerts header ="Check Cleared"></RenderCheckboxForAccountAlerts>
                <RenderCheckboxForAccountAlerts header ="Negative Balance"></RenderCheckboxForAccountAlerts>
                <RenderCheckboxForAccountAlerts header ="Card Transaction"></RenderCheckboxForAccountAlerts>
                <RenderCheckboxForAccountAlerts header ="Card Transaction Threshold"></RenderCheckboxForAccountAlerts>
                <RenderCheckboxForAccountAlerts header ="Current Posted Balance"></RenderCheckboxForAccountAlerts>               
                {/* <Row>
                    <Col xs="8" sm="8" md="8" lg="8">
                            <div className="headers">
                                <h5>Overdraft Posted</h5>                              
                            </div> 
                        </Col>
                        <Col xs="4" sm="4" md="4" lg="4">
                            <img alt="enable"/>                  
                        {/* <img className="colrightalign" src={'/images/' + (this.state['email1'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('email1')} alt="enable"/>  
                    </Col>
                </Row>
                <hr></hr> */}
                {/* <Row>
                    <Col xs="8" sm="8" md="8" lg="8">
                            <div className="headers">
                                <h5>Check Cleared</h5>                              
                            </div> 
                        </Col>
                        <Col xs="4" sm="4" md="4" lg="4">
                            <img alt="enable"/>                  
                        <img className="colrightalign" src={'/images/' + (this.state['email1'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('email1')} alt="enable"/> 
                    </Col>
                </Row>
                <hr></hr> */}
                {/* <Row>
                    <Col xs="8" sm="8" md="8" lg="8">
                            <div className="headers">
                                <h5>Negative Balance</h5>                              
                            </div> 
                        </Col>
                        <Col xs="4" sm="4" md="4" lg="4">
                            <img alt="enable"/>                  
                        {/* <img className="colrightalign" src={'/images/' + (this.state['email1'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('email1')} alt="enable"/>  
                    </Col>
                </Row>
                <hr></hr> */}
                {/* <Row>
                    <Col xs="8" sm="8" md="8" lg="8">
                            <div className="headers">
                                <h5>Card Transaction</h5>                              
                            </div> 
                        </Col>
                        <Col xs="4" sm="4" md="4" lg="4">
                            <img alt="enable"/>                  
                        <img className="colrightalign" src={'/images/' + (this.state['email1'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('email1')} alt="enable"/> 
                    </Col>
                </Row> 
                <hr></hr>*/}
                {/* <Row>
                    <Col xs="8" sm="8" md="8" lg="8">
                            <div className="headers">
                                <h5>Card Transaction Threshold</h5>                              
                            </div> 
                        </Col>
                        <Col xs="4" sm="4" md="4" lg="4">
                            <img alt="enable"/>                  
                        <img className="colrightalign" src={'/images/' + (this.state['email1'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('email1')} alt="enable"/> 
                    </Col>
                </Row>
                <hr></hr>
                <Row>
                    <Col xs="8" sm="8" md="8" lg="8">
                            <div className="headers">
                                <h5>Current Posted Balance</h5>                              
                            </div> 
                        </Col>
                        <Col xs="4" sm="4" md="4" lg="4">
                            <img alt="enable"/>                  
                        <img className="colrightalign" src={'/images/' + (this.state['email1'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('email1')} alt="enable"/> 
                    </Col>
                </Row> */}
            </div>
        </div>
    );   
}
}

export default accountAlerts;