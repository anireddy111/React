import React, { Component } from 'react';
import {Row,Col,Container }from 'react-bootstrap';
import './landingPage.css';
const imagePath = process.env.PUBLIC_URL + '/Images/';
class landingPage extends Component {
constructor(props){
  super(props);
  this.state={
  username:'',
  password:''
  }
 }
render() {
    return ( 
        <div>    
    {/* <div className="container"> */}
    <Container className="container">
       <Row >
           <Col xs="12" sm="12" md="3" lg="3">
           <h3 className="Headers" >
        Banking Alerts
      </h3>
      <hr ></hr>
      <div className="shadowEffect">
      <a
        className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           Security
         </a>
        <hr className="GreyHr"></hr>
        <a
        className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           Regions LockIt
         </a>
      </div>
           </Col>                 
           <Col xs="12" sm="12" md="4" lg="4">
           <h3 className="Headers">
        Account Alerts
      </h3>
      <hr className="hrWidth" ></hr>
      <div className="shadowEffect">
      <a
        className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           LifeGreen Preferred *1234
         </a>
        <hr className="GreyHr"></hr>
        <a
        className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          LifeGreen Savings *9012
         </a>
         <hr className="GreyHr"></hr>
        <a
        className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           Prestige VISA Signature *3456
         </a>
      </div>
           </Col>
           <Col xs="12" sm="12" md="4" lg="4">
           <h3 className="Headers">
        Alert Preferences
      </h3>
      <hr className="hrWidth" ></hr>
      <div className="shadowEffect">
      <a
        className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           Add / Edit Delivery Methods
         </a>
        <hr className="GreyHr"></hr>
        <a
        className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           Manage Text Banking
         </a>
      </div>
           </Col>
           <Col xs="12" sm="12" md="3" lg="3">
           <div id="WelcomeTab">
       <h5>
        WELCOME
      </h5>
      <hr></hr>
      <p>
        Profile Name
      </p>
      <a
        className="Link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           EMAIL@ADDRESS.COM
         </a>        
         <p>
        205-123-4567
      </p>
      <a
        className="Link editSize"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           Manage Contact & Security Information
         </a> 
         <hr></hr>
         <h6>
           Contact Us
           </h6>
           <img src={`${imagePath}emailIcon.PNG`} className="Mail-logo" alt="logo" />  
           <a
        className="Link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           Message Center(0)
         </a> 
         <div>
         <img src={`${imagePath}phoneIcon.PNG`} className="Phone-logo" alt="logo" />  
         
           1-800-734-4667
         
         </div>
         <a
        className="Link editSize"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           view all contact information
         </a> 
         <div>
         <a
        className="Link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           Leave Feedback
         </a>
         </div>
         <hr></hr>
         <a
        className="Link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           Need Help?
         </a> 
         <hr></hr>
         <h6>
           Find Us
         </h6>
         <img src={`${imagePath}locationIcon.PNG`} className="Phone-logo" alt="logo" />  
         <a
        className="Link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
           Locate a Branch or ATM
         </a> 
         </div>
       </Col>
       </Row>
       {/* <Row>
       <div>
  <img onClick={() => {this.setState({clicked: true})}}
       src={'/Images/' + (this.state.clicked ? 'phoneIcon' : 'emailIcon') + '.png'} />
     
</div>
       </Row> */}
      </Container>
      </div>  
//</div>
 );
}
}
// const style = {
// margin: 15,
// };
export default landingPage;