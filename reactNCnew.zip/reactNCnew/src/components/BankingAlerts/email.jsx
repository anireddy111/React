import React, { component } from 'react';
import '../BankingAlerts/email.css';
import { Row, Col } from 'react-bootstrap';
import ToggleComponent from '../../Shared/toggleComponent';


class EmailComponent extends React.Component {

  render() {

    return (
      <div id="dvEmailsection" className="px-2">
        <h5>Email</h5>
        <hr></hr>
        {this.props.emailItems.map(item => {
          return <Row>
            <Col>
              <label className="colleftalign" >{item.name}</label>
            </Col>
            <Col>
            <ToggleComponent></ToggleComponent>
              {/* <img className="colrightalign" src={'/images/' + (item.enabled ? 'enableIcon' : 'disableIcon') + '.png'} onClick={() => this.props.toggleBankingAlerts(item)} alt={item.enabled.toString()} /> */}
            </Col>
          </Row>
        })}
        <hr></hr>
      </div>
    );
  }
}
export default EmailComponent;