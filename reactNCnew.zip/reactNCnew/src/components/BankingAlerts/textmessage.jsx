import React, {Component} from 'react';
import './email.css';
import { Row, Col } from 'react-bootstrap';
import ToggleComponent from '../../Shared/toggleComponent';

class TextMessageComponent extends Component {
constructor(props)
{
super(props);
this.state = {
    notify1: true,
    notify2:true
  }
}
  toggleImage(toggler) {
      let togglerstatus = this.state[toggler];
    this.setState({
[toggler]:!togglerstatus       
    });
  }

  
render(){
    
return(
    <div id="dvpushnotifysection" className="px-2">
    <h5>Text Message</h5>
<hr></hr>
<Row>
    <Col>
    <label className="colleftalign" >1-205-555-5555</label>
    </Col>
    <Col>          
    {/* <img className="colrightalign"  src={'/images/' + (this.state['notify1'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('notify1')} alt="enable"/> */}
    <ToggleComponent></ToggleComponent>
    </Col>
</Row>
<hr></hr>
</div>
);


}

}
export default TextMessageComponent;