import React, { Component } from 'react';
//import './Style/checkbox.css';

class checkbox extends Component {
  state = {
    isChecked: false,
  }

  toggleCheckboxChange = () => {
    const { handleCheckboxChange, label } = this.props;

    this.setState(({ isChecked }) => (
      {
        isChecked: !isChecked,
      }
    ));

    handleCheckboxChange(label);
  }

  render() {
    const { label } = this.props;
    const { isChecked } = this.state;

    return (
      <div className="checkbox">      
            <label>
            <input
                                type="checkbox"
                                value={label}
                                checked={isChecked}
                                onChange={this.toggleCheckboxChange}                                
                            />
            {label}
            </label>       
      </div>


    // <div className="btn-group" data-toggle="buttons">
			
	// 		<label className="btn btn-success active">
    //             <input 
    //                 type="checkbox" 
    //                 autoComplete="off"
    //                 value={label}
    //                 checked={isChecked}
    //                 onChange={this.toggleCheckboxChange}    
    //                  />
	// 			<span className="glyphicon glyphicon-ok"></span>
    //             {label}
	// 		</label>
    //         </div>
    );
  }
}

// checkbox.propTypes = {
//   label: PropTypes.string.isRequired,
//   handleCheckboxChange: PropTypes.func.isRequired,
// };

export default checkbox;