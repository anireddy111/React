import React,{Component} from 'react';
import './Style/toggle.css';

class toggleComponent extends Component{   
    // constructor(props) {
    //     super(props)
    // }
    render ()
    {       
        return (
            <div className="alignColRight">
                <label className="switch">
                    <input type="checkbox" id="togBtn"/>
                        <div className="slider">
                            <span className="on">ON</span>
                            <span className="off">OFF</span>
                        </div>
                </label>
            </div>
        );
    }
}
export default toggleComponent;