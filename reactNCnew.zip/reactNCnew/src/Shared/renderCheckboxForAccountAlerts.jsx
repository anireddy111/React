import React from 'react';
import { Col, Row } from 'react-bootstrap';
import '../Shared/Style/header.css';
import AccountAlertsSection from '../Shared/accountAlertsSection';
import ToggleComponent from '../Shared/toggleComponent';

 class HeaderComponent extends React.Component {
    constructor(props)
    {
    super(props);
    this.state = {
        email: true,        
      }
    }
      toggleImage(toggler) {
          let togglerstatus = this.state[toggler];
        this.setState({
    [toggler]:!togglerstatus       
        });
      }
    render() {
        return (
        
        <div>          
            <Row>
                    <Col xs="8" sm="8" md="8" lg="8">
                            <div className="headers">
                                <h5>{this.props.header}</h5>                              
                            </div> 
                        </Col>
                        <Col xs="4" sm="4" md="4" lg="4">                                         
                        {/* <img className="colrightalign" src={'/images/' + (this.state['email'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('email')} alt="enable"/>  */}
                        <ToggleComponent></ToggleComponent>
                    </Col>
                    <div className="col-12" style={{ display: (this.state['email'] ? 'block' : 'none') }}>                                   
                    <AccountAlertsSection />                                        
                    </div>
                </Row>
                <hr></hr>



        </div>);
    }
}
export default HeaderComponent;
