import React from 'react';
import { Col, Row } from 'react-bootstrap';
import '../Shared/Style/header.css';

 class HeaderComponent extends React.Component {
    // constructor(props) {
    //     super(props);
    // }
    render() {
        return (<div id="headerDisplay" className="px-2 col-12">

            <Row className="alignbacktext">
                <Col>
                    <div>
                        <img className="header" src="/images/backIcon.png" alt="backicon"></img>
                        <a href="/landingPage" className="hreftextcolor">Notification Center</a>
                    </div>
                </Col>
            </Row>



            <Row>
                <Col>
                    <h4>{this.props.displaytext}</h4>
                    <hr className="hrcolor"></hr>
                </Col>
            </Row>
            <Row>
                <Col>
                    <h5>Set Up {this.props.displaytext}</h5>
                </Col>
            </Row>
            <Row>
                <Col>
                    <p>{this.props.descriptiontext1}
                        {this.props.descriptiontext2}</p>
                </Col>
            </Row>



        </div>);
    }
}
export default HeaderComponent;
