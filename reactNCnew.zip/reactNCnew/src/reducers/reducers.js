import bankingAlertsReducer from './bankingAlertsReducer';
import accountAlertsReducer from './accountAlertsReducer';
import { combineReducers } from 'redux';
// export default combineReducers({
//     bankingAlerts: bankingAlertsReducer
// });

const rootReducer= combineReducers({
         bankingAlertsReducer,
         accountAlertsReducer
    });

    export default rootReducer;