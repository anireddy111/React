import {Get_Account_Alerts} from '../actions/actionTypes'


const initialState ={
pending:false,
landingPage:[]
}

export default function accountAlertsReducer(state=initialState,action){
switch (action.type) {
    case Get_Account_Alerts:
        
return {
...state,
isFetching:true,
didInvalidate:false,
lastUpdated:action.receivedAt,
items:action.posts,
}
     

    default:
        return state;
}


}