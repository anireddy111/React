import {Get_Bank_Alerts} from '../actions/actionTypes'


const initialState ={
pending:false,
landingPage:[]
}

export default function bankingAlertsReducer(state=initialState,action){
switch (action.type) {
    case Get_Bank_Alerts:
        
return {
...state,
isFetching:true,
didInvalidate:false,
lastUpdated:action.receivedAt,
items:action.posts,
}
     

    default:
        return state;
}


}