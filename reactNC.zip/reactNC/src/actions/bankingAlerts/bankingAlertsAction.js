import { TOGGLE_BANKING_ALERTS } from '../actionTypes'

export const toggleBankingAlerts = (item) => dispatch => {
    dispatch({
        type: TOGGLE_BANKING_ALERTS,
        payload: item
    })
}