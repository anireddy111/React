import React, { Component } from 'react';
import {Row,Col }from 'react-bootstrap';
 //import './accountAlerts.css';
 import Checkbox from '../Shared/checkbox';

 const items = [
    'workaddress@email.com',
    'address@email.com',
  ];

const itemsForPush=[
    'Profile Name`s iPhone',
    'iPad Pro',
]

const itemsForText=[
    '1-205-555-5555'
]

class accountAlertsSection extends Component { 
    componentDidMount = () => {
        this.selectedCheckboxes = new Set();
    }
    
    toggleCheckbox = label => {
        if (this.selectedCheckboxes.has(label)) {
          this.selectedCheckboxes.delete(label);
        } 
        else {
          this.selectedCheckboxes.add(label);
        }
    }     

      createCheckbox = label => (
        <Checkbox
                label={label}
                handleCheckboxChange={this.toggleCheckbox}
                key={label}
            />
      )
    
      createCheckboxes = () => (
        items.map(this.createCheckbox)
      )

      createCheckboxesPush = () => (
        itemsForPush.map(this.createCheckbox)
      )

      createCheckboxesText = () => (
        itemsForText.map(this.createCheckbox)
      )
      render() {
        return ( 
           <div>
      <Row className="rowAlign">
                    <Col xs="12" sm="12" md="4" lg="4">
                    <div>
                        Email
                    </div>                    
                    {this.createCheckboxes()}
                    </Col>
                    <Col xs="12" sm="12" md="4" lg="4">
                    <div>
                        Push Notifications
                    </div>                    
                     {this.createCheckboxesPush()}
                    </Col>
                    <Col xs="12" sm="12" md="4" lg="4">
                    <div>
                        Text Message
                    </div>                    
                    {this.createCheckboxesText()}
                    </Col>
                </Row>
                </div>
);   
}
}

export default accountAlertsSection;