import React, {component} from 'react';
 import {Button} from 'react-bootstrap'

 class HeaderComponent extends 
React.Component {

   constructor(props){
super(props)
    }

    render(){
        const element = (<div>Testing adding Component</div>)
        return (
            <div className="xs-1">
                <Button bsStyle="primary">Primary</Button>
<h3>Component example</h3>
{this.props.displaytext}
{element}
            </div>);  
        }
}

export default HeaderComponent;
