import React,{Component} from 'react';
import './Style/toggle.css';

class toggleComponent extends Component{   
    // constructor(props) {
    //     super(props)
    // }
    render ()
    {
        return (
            <div>
                <div className="slideparam">
                    <input type="checkbox" id="slideparam_1" value="1" />
                    <label htmlFor="slideparam_1"></label>
                </div>
                {/* <div class="slideparam">
                    <input type="checkbox" id="slideparam_2" value="2" />
                    <label for="slideparam_2"></label>
                </div>
                <div class="slideparam">
                    <input type="checkbox" id="slideparam_3" value="3" />
                    <label for="slideparam_3"></label>
                    </div> */}
            </div>
        );
    }
}
export default toggleComponent;