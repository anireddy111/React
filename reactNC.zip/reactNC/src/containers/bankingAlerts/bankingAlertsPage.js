import React, { Component } from 'react';
import { connect } from 'react-redux';
import { compose, bindActionCreators } from 'redux';
import EmailComponent from '../../components/BankingAlerts/email';
import 'bootstrap/dist/css/bootstrap.min.css';
import PushNotificationComponent from '../../components/BankingAlerts/pushnotification';
import TextMessageComponent from '../../components/BankingAlerts/textmessage';
import { withRouter } from 'react-router-dom';
import HeaderComponent from '../../Shared/HeaderComponent';
import { Row } from 'react-bootstrap';
import { toggleBankingAlerts } from '../../actions/actions'

class BankingAlertsPage extends Component {

    // constructor(props) {
    //     super(props)
    // }
    render() {
        console.log('state', this.props);
        return (
            <div className="container-box">
                <Row>
                    <HeaderComponent displaytext="Security Alerts" descriptiontext1="These notification may include updates to your online banking settings, claim status and other important issues." descriptiontext2="You must select atlest one delivery method." >
                    </HeaderComponent>
                </Row>
                <EmailComponent emailItems={this.props.bankingAlerts.email} toggleBankingAlerts={this.props.toggleBankingAlerts}></EmailComponent>
                <PushNotificationComponent></PushNotificationComponent>
                <TextMessageComponent></TextMessageComponent>

            </div>
        );

    }
}
const mapStateToProps = state => ({
    bankingAlerts: state.bankingAlerts
})

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators({ toggleBankingAlerts }, dispatch);
}
export default compose(
    withRouter,
    connect(mapStateToProps, mapDispatchToProps)
)(BankingAlertsPage);

