import React, {Component} from 'react';
import EmailComponent from '../email';
import 'bootstrap/dist/css/bootstrap.min.css';
import PushNotificationComponent from '../pushnotification';
import TextMessageComponent from '../textmessage';
import {withRouter} from 'react-router-dom';
import HeaderComponent from '../../../Shared/HeaderComponent';
import { Row } from 'react-bootstrap';
import ToggleComponent from '../../../Shared/toggleComponent';

class regionsLockIt extends Component
{

    // constructor(props) {
    //     super(props)
    // }
    render (){
return (
<div className="container-box">
<Row>
    <HeaderComponent displaytext ="Regions LockIt Alerts" descriptiontext1 ="These notification may include updates regarding any Regions LockIt activity, such as blocked transactions and other important issues." descriptiontext2 ="" >      
    </HeaderComponent>
</Row>
<EmailComponent></EmailComponent>
<PushNotificationComponent></PushNotificationComponent>
<TextMessageComponent></TextMessageComponent>
<ToggleComponent></ToggleComponent>
   
</div>


);

    }



}

export default withRouter(regionsLockIt);

 