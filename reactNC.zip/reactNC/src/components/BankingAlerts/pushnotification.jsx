import React, {Component} from 'react';
import './email.css';
import { Row, Col } from 'react-bootstrap';


class PushNotificationComponent extends Component
{
constructor(props)
{
super(props);
this.state = {
    notify1: true,
    notify2:true
  }
}
  toggleImage(toggler) {
      let togglerstatus = this.state[toggler];
    this.setState({
[toggler]:!togglerstatus       
    });
  }

  
render(){
    
return(
    <div id="dvpushnotifysection" className="px-2">
    <h5>Push Notification</h5>
<hr></hr>
<Row>
    <Col>
    <label className="colleftalign" >Profile Name's iPhone</label>
    </Col>
    <Col>          
    <img className="colrightalign"  src={'/images/' + (this.state['notify1'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('notify1')} alt="enable"/>
    </Col>
</Row>
<Row>
<Col>
    <label className="colleftalign" >iPad Pro</label>
    </Col>
    <Col>    
    <div>    
 <img className="colrightalign"  src={'/images/' + (this.state['notify2'] ? 'enableIcon' : 'disableIcon') + '.png'} onClick={()=>this.toggleImage('notify2')} alt="enable"/>

      </div>
    </Col>
</Row>
<hr></hr>
</div>
);


}

}
export default PushNotificationComponent;