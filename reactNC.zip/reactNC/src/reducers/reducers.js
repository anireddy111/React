import bankingAlertsReducer from './bankingAlerts/bankingAlertsReducer';
import { combineReducers } from 'redux';
export default combineReducers({
    bankingAlerts: bankingAlertsReducer
});