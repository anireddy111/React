
import { TOGGLE_BANKING_ALERTS } from '../../actions/actionTypes'

const initialState = {
    email: [{
        name: 'workaddress@email.com',
        enabled: false
    },
    {
        name: 'address@email.com',
        enabled: false
    }]
};


const bankingAlertReducers = (state = initialState, action) => {
    switch (action.type) {
        case TOGGLE_BANKING_ALERTS:
            return {
                ...state, email: state.email.map(email => {
                    if (email.name === action.payload.name) {
                        return { ...email, enabled: !email.enabled }
                    }
                    return email
                })
            }
        default:
            return state
    }
}

export default bankingAlertReducers;
